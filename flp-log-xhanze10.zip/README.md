# Babylonská veža
Autor: Svätopluk Hanzel (xhanze10)

Program nájde riešenie hlavolamu Babylonská veža pomocou prehľadávania priestoru, pričom postupne prehľadáva až do hĺbky 15. Nové stavy sa generujú pomocou hýbania s voľným priestorom alebo rotáciou prstencov.

## Testovacie dáta
* input1 - posun o 2 políčka dole - 0.01s
* input2 - rotácia - 0.01s
* input3 - komplexnejsie pohyby - 0.72s
* input42 - velky vstup - ~40min
