% FLP - Projekt 2
% Vitezslav Kriz - xkrizv01

:- dynamic hole/1.

main :-
  prompt(_, ''),
  readFile(Input,user_input),
  size(Input, Rows, Cols),
  assertz(hole('A':Rows)),
  t(_,_,Input, '*', 'A':Rows, Tower),!,
  correct(Rows, Cols, Goal),
  (
   solve(Tower, 3, Goal, Moves, []);
   solve(Tower, 5, Goal, Moves, []);
   solve(Tower, 10, Goal, Moves, [])
   % Dalsi prohledavani je jiz moc casove narocne
  ),
  !,
  writeTower(Tower),nl,
  replay(Tower, Moves),
  retractall(hole('A':Rows)).

%%%% Nacteni veze

% Vypise vez
writeTower([]).
writeTower([Row|T]) :-
  writeRow(Row),
  writeTower(T).

writeRow([]) :- nl.
writeRow([H|Row]) :- hole(H),write('** '),!,writeRow(Row).
writeRow([A:B|Row]) :-
  write(A),write(B),write(' '),
  writeRow(Row).

% Nacte vez ze souboru
readFile(Matrix) :-
  open('input1',read,File),
  readFile(Matrix, File),!,
  close(File).

readFile([], File) :- at_end_of_stream(File).
readFile([List|M], File) :-
  read_line_to_codes(File,Line),
  parseLine(Line,List),
  readFile(M, File).

% Zpracuje jeden radek
parseLine([32|In], Out) :- !,parseLine(In, Out).
parseLine([42,42|In], ['*'|Out]) :-!,parseLine(In, Out).
parseLine([A,B|In], [C:N|Out]) :-
  char_code(C, A),
  N is B - 48,
  parseLine(In, Out).
parseLine([], []).
parseLine([32|In], [E|Out], E) :- parseLine(In, Out).

%%%% Generovani spravne usporadane veze

alphabet(['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']).
%alphabet(['A', 'B', 'C', 'D']).

alphabet(N,A) :-
  alphabet(ABC),length(ABC,LenABC),!,
  between(1,LenABC,N),
  length(A,N),
  prefix(A,ABC).

% spravne vyresena vez
correct(Rows,Cols,T) :-
  length(T,Rows),
  numlist(1,Rows,A),
  maplist(correctRow(Cols),A,T).

combine(B,A,A:B).
correctRow(Cols,N,Row) :- alphabet(Cols,R),maplist(combine(N),R,Row).

% vybere z veze pouze barvy
onlyColors(T,R) :- maplist(mapFirst,T,R).
mapFirst([],[]).
mapFirst([A:_|T],[A:_|R]) :- mapFirst(T,R).

%%%% Zakladni operace s vezi

% Zjisti velikost veze, generovani spravne velke veze nebude uspesne.
size(T, Rows, Cols) :- length(T, Rows),member(Row,T),!,length(Row,Cols).

% Ziska prvek na X, Y ve vezi T
t(X,Y,T,E) :- nth1(Y,T,Row),nth1(X,Row,E).

% Nahradi prvek ve vezi
t(X,Y,T,E,NE,R) :-
  nth1(Y,T,Row),
  nth1(X,Row,E),
  select(E,Row,NE,NewRow),
  select(Row,T,NewRow,R).

%%%%% Pohyby s vezi

% Posun volneho mista
move_hole(T, R, hole:DIR) :-
  hole(H),
  ((nextto(Row,MoveRow,T),DIR=down);(nextto(MoveRow,Row,T),DIR=up)),
  nth1(X,Row,H),
  nth1(X,MoveRow,MoveElem),
  select(MoveElem,MoveRow,H,NewMoveRow),
  select(H,Row,MoveElem,NewRow),
  select(Row,T,NewRow,NewT),
  select(MoveRow,NewT,NewMoveRow,R).

% Rotace radku
move_rotate(T, Res, rotL:N) :- nth1(N,T,A),rotate(A,B),select(A,T,B,Res).
move_rotate(T, Res, rotR:N) :- nth1(N,T,A),rotate(B,A),select(A,T,B,Res).
rotate([H|T],R) :- append(T,[H],R).

% Kombinace pohybu
move(T,R,M) :- move_rotate(T,R,M);move_hole(T,R,M).

% inverzni pohyb, da se pouzit pro vyuziti komutatoru permutace
inverse_move(rotL:N,rotR:N).
inverse_move(rotR:N,rotL:N).
inverse_move(hole:up,hole:down).
inverse_move(hole:down,hole:up).

solve(T,_,T,[],_).
solve(_,N,_,_,_) :- N =< 0,!,fail.
solve(T,N,G,[M|S], History) :-
  N > 0,
  N1 is N-1,
  move(T,R1,M),
  not(member(R1,History)),
  solve(R1,N1,G,S,[T|History]).

% Na zaklade zapsananych pohybu vypise stavy veze
replay(_, []) :- !.
replay(T, [Move|Moves]) :-
  move(T, R, Move),
  writeTower(R),
  nl,!,
  replay(R, Moves).





